import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'converter.dart';
import 'engine.dart';
import 'programmer.dart';

// ------------------------------------------------------------ device target
/// Set at build time: --dart-define=TARGET=tv | mobile (default: auto-detect)
const kTarget = String.fromEnvironment('TARGET', defaultValue: 'auto');
const channel = MethodChannel('maraj/device');

/// true on TV / Jio STB, false on phones & tablets.
bool isTv = true;

/// Low-RAM device (typical 1 GB STB).
bool lowEnd = false;

/// Glass blur strength. TV on a weak GPU (1 GB STB) skips the blur filter and
/// falls back to translucent gradient glass, so CPU/GPU stays well under 50%.
double get panelBlur => isTv ? (lowEnd ? 0 : 14) : 24;

Future<void> detectTarget() async {
  if (kTarget == 'tv') {
    isTv = true;
  } else if (kTarget == 'mobile') {
    isTv = false;
  } else {
    try {
      isTv = (await channel.invokeMethod<bool>('isTv')) ?? true;
    } catch (_) {
      isTv = true;
    }
  }
  try {
    lowEnd = (await channel.invokeMethod<bool>('lowEnd')) ?? false;
  } catch (_) {
    lowEnd = false;
  }
}

// ---------------------------------------------------------------- scientific
class HistoryItem {
  HistoryItem(this.expr, this.result);
  final String expr, result;
}

class SciController extends ChangeNotifier {
  String expr = '';
  String preview = '';
  String? error;
  bool degrees = true;
  bool second = false;
  bool hasMemory = false;
  double memory = 0;
  double ans = 0;
  bool _fresh = false; // last action was "="
  final List<HistoryItem> history = <HistoryItem>[];

  static const _binary = <String>['+', '−', '×', '÷', '^'];
  static final RegExp _fnTail = RegExp(
      r'(asin|acos|atan|sinh|cosh|tanh|sin|cos|tan|log2|log|ln|sqrt|cbrt|abs|exp|floor|ceil|round|ncr|npr|fact|√)\($| mod $');

  bool _continues(String t) =>
      _binary.contains(t) ||
      t == '!' ||
      t == '%' ||
      t == ' mod ' ||
      t.startsWith('^');

  void press(String t) {
    if (_fresh && !_continues(t)) expr = '';
    _fresh = false;
    error = null;
    if (expr.isEmpty && (t == '×' || t == '÷' || t == '^' || t == '!' || t == '%')) {
      return;
    }
    if (_binary.contains(t) && expr.isNotEmpty) {
      final last = expr[expr.length - 1];
      if (_binary.contains(last)) {
        final keepSign = t == '−' && (last == '×' || last == '÷' || last == '^');
        if (!keepSign) expr = expr.substring(0, expr.length - 1);
      }
    }
    expr += t;
    _update();
  }

  void backspace() {
    if (expr.isEmpty) return;
    final m = _fnTail.firstMatch(expr);
    expr = m != null ? expr.substring(0, m.start) : expr.substring(0, expr.length - 1);
    _fresh = false;
    error = null;
    _update();
  }

  void clear() {
    expr = '';
    preview = '';
    error = null;
    _fresh = false;
    notifyListeners();
  }

  void _update() {
    try {
      preview = fmt(Evaluator(degrees: degrees, ans: ans).eval(expr));
    } catch (_) {
      preview = '';
    }
    notifyListeners();
  }

  void equals() {
    if (expr.isEmpty) return;
    try {
      final v = Evaluator(degrees: degrees, ans: ans).eval(expr);
      final r = fmt(v);
      history.insert(0, HistoryItem(expr, r));
      if (history.length > 200) history.removeLast();
      ans = v;
      expr = r;
      preview = '';
      _fresh = true;
      error = null;
    } on CalcError catch (e) {
      error = e.message;
    } catch (_) {
      error = 'Syntax error';
    }
    notifyListeners();
  }

  void toggleAngle() {
    degrees = !degrees;
    _update();
  }

  void toggleSecond() {
    second = !second;
    notifyListeners();
  }

  void clearHistory() {
    history.clear();
    notifyListeners();
  }

  // memory
  double? _currentValue() {
    if (expr.isEmpty) return null;
    try {
      return Evaluator(degrees: degrees, ans: ans).eval(expr);
    } catch (_) {
      return null;
    }
  }

  void memAdd(int sign) {
    final v = _currentValue();
    if (v == null) return;
    memory += sign * v;
    hasMemory = true;
    notifyListeners();
  }

  void memRecall() {
    if (hasMemory) press(fmt(memory));
  }

  void memClear() {
    memory = 0;
    hasMemory = false;
    notifyListeners();
  }
}

class Models {
  final SciController sci = SciController();
  final ProgController prog = ProgController();
  final ConvController conv = ConvController();
}
