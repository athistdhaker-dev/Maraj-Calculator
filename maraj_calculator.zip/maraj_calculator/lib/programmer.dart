import 'package:flutter/foundation.dart';
import 'engine.dart';

/// 64-bit signed programmer calculator (HEX / DEC / OCT / BIN).
class ProgController extends ChangeNotifier {
  int base = 10;
  int cur = 0;
  bool entering = false;
  int? acc;
  String? op;
  String? error;

  static final BigInt _two64 = BigInt.one << 64;
  static final BigInt _maxS = BigInt.parse('9223372036854775807');

  static String group(String s) {
    final b = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 4 == 0) b.write(' ');
      b.write(s[i]);
    }
    return b.toString();
  }

  static String text(int v, int base, {bool grouped = false}) {
    if (base == 10) return v.toString();
    final s = BigInt.from(v).toUnsigned(64).toRadixString(base).toUpperCase();
    return grouped && (base == 16 || base == 2) ? group(s) : s;
  }

  String get mainText => text(cur, base, grouped: true);
  String get pending => (acc != null && op != null) ? '${text(acc!, base)} $op' : '';

  void setBase(int b) {
    base = b;
    notifyListeners();
  }

  void digit(int d) {
    if (d >= base) return;
    error = null;
    final start = entering ? BigInt.from(cur).toUnsigned(64) : BigInt.zero;
    final n = start * BigInt.from(base) + BigInt.from(d);
    if (n >= _two64) return;
    if (base == 10 && n > _maxS) return;
    cur = n.toSigned(64).toInt();
    entering = true;
    notifyListeners();
  }

  void backspace() {
    if (!entering) return;
    final u = BigInt.from(cur).toUnsigned(64) ~/ BigInt.from(base);
    cur = u.toSigned(64).toInt();
    notifyListeners();
  }

  void clear() {
    cur = 0;
    acc = null;
    op = null;
    entering = false;
    error = null;
    notifyListeners();
  }

  void not() {
    cur = ~cur;
    entering = false;
    error = null;
    notifyListeners();
  }

  int _apply(int a, int b, String o) {
    switch (o) {
      case '+':
        return a + b;
      case '−':
        return a - b;
      case '×':
        return a * b;
      case '÷':
        if (b == 0) throw CalcError('Cannot divide by zero');
        return a ~/ b;
      case 'MOD':
        if (b == 0) throw CalcError('Cannot divide by zero');
        return a.remainder(b);
      case 'AND':
        return a & b;
      case 'OR':
        return a | b;
      case 'XOR':
        return a ^ b;
      case '<<':
        return a << (b & 63);
      case '>>':
        return a >> (b & 63);
    }
    return b;
  }

  void _fail(CalcError e) {
    error = e.message;
    cur = 0;
    acc = null;
    op = null;
    entering = false;
    notifyListeners();
  }

  void setOp(String o) {
    error = null;
    if (op != null && entering) {
      try {
        cur = _apply(acc ?? 0, cur, op!);
      } on CalcError catch (e) {
        _fail(e);
        return;
      }
    }
    acc = cur;
    op = o;
    entering = false;
    notifyListeners();
  }

  void equals() {
    if (op == null) return;
    try {
      cur = _apply(acc ?? 0, cur, op!);
      error = null;
    } on CalcError catch (e) {
      _fail(e);
      return;
    }
    op = null;
    acc = null;
    entering = false;
    notifyListeners();
  }
}
