import 'package:flutter/material.dart';

import 'core.dart';
import 'glass.dart';
import 'pages.dart';
import 'ui.dart';

/// TV / Jio STB layout: glass rail on the left + big D-pad friendly panel.
class TvHome extends StatefulWidget {
  const TvHome({super.key});
  @override
  State<TvHome> createState() => _TvHomeState();
}

class _TvHomeState extends State<TvHome> {
  final Models m = Models();
  int tab = 0;

  static const _labels = <String>['Scientific', 'Programmer', 'Convert', 'History', 'About & Legal'];
  static const _icons = <IconData>[
    Icons.calculate,
    Icons.code,
    Icons.swap_horiz,
    Icons.history,
    Icons.info_outline,
  ];

  Widget _panel() {
    switch (tab) {
      case 1:
        return ProgPanel(c: m.prog);
      case 2:
        return ConvPanel(c: m.conv);
      case 3:
        return HistoryPanel(
          c: m.sci,
          onPick: (h) {
            m.sci.press(h.result);
            setState(() => tab = 0);
          },
        );
      case 4:
        return const InfoPanel();
      default:
        return SciPanel(c: m.sci);
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Padding(
        // TV safe margins (overscan)
        padding: EdgeInsets.symmetric(
            horizontal: size.width * 0.04, vertical: size.height * 0.05),
        child: Row(
          children: <Widget>[
            SizedBox(
              width: size.width * 0.2,
              child: Glass(
                radius: 30,
                blur: panelBlur,
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const Padding(
                      padding: EdgeInsets.fromLTRB(8, 6, 8, 14),
                      child: Text('Maraj\nCalculator',
                          style: TextStyle(
                              fontSize: 24,
                              height: 1.1,
                              fontWeight: FontWeight.w700,
                              color: Pal.eq)),
                    ),
                    for (var i = 0; i < _labels.length; i++)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: GlassTap(
                          radius: 18,
                          selected: tab == i,
                          tint: tab == i ? Pal.eq : null,
                          tintStrength: 0.45,
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                          onTap: () => setState(() => tab = i),
                          child: Row(
                            children: <Widget>[
                              Icon(_icons[i], color: Pal.text, size: 22),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(_labels[i],
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        color: Pal.text)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    const Spacer(),
                    const Padding(
                      padding: EdgeInsets.all(8),
                      child: Text('◀ ▶ ▲ ▼ move   OK select',
                          style: TextStyle(color: Pal.dim, fontSize: 12)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(child: _panel()),
          ],
        ),
      ),
    );
  }
}
