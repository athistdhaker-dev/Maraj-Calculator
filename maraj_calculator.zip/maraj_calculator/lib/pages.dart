import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core.dart';
import 'glass.dart';
import 'legal.dart';
import 'ui.dart';

List<String> _blocks(String body) =>
    body.split('\n\n').where((s) => s.trim().isNotEmpty).toList();

Future<List<String>> _licenses() async {
  final out = <String>[
    '$kAppName is built with Flutter and the Dart SDK (BSD-3-Clause). '
        'The licenses of all bundled open-source components are listed below.',
  ];
  await for (final e in LicenseRegistry.licenses) {
    final b = StringBuffer(e.packages.join(', '));
    for (final p in e.paragraphs) {
      b.write('\n${p.text}');
    }
    out.add(b.toString());
  }
  return out;
}

/// "About & Legal" screen (Privacy Policy, T&C, open-source licenses, version).
class InfoPanel extends StatelessWidget {
  const InfoPanel({super.key});

  @override
  Widget build(BuildContext context) {
    void open(String t, Future<List<String>> blocks) => Navigator.push(
          context,
          MaterialPageRoute<void>(builder: (_) => DocPage(title: t, blocks: blocks)),
        );
    Widget row(IconData i, String t, VoidCallback f, {bool autofocus = false}) =>
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: GlassTap(
            autofocus: autofocus,
            radius: 24,
            onTap: f,
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            child: Row(children: <Widget>[
              Icon(i, color: Pal.eq),
              const SizedBox(width: 14),
              Expanded(
                child: Text(t,
                    style: TextStyle(
                        fontSize: isTv ? 20 : 17,
                        fontWeight: FontWeight.w600,
                        color: Pal.text)),
              ),
              const Icon(Icons.chevron_right, color: Pal.dim),
            ]),
          ),
        );
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 640),
        child: Glass(
          radius: 30,
          blur: panelBlur,
          padding: const EdgeInsets.all(18),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Text(kAppName,
                    style: TextStyle(
                        fontSize: 24, fontWeight: FontWeight.w700, color: Pal.text)),
                const SizedBox(height: 4),
                const Text('Version $kVersion', style: TextStyle(color: Pal.dim)),
                const SizedBox(height: 16),
                row(Icons.privacy_tip_outlined, 'Privacy Policy',
                    () => open('Privacy Policy', Future.value(_blocks(kPrivacy))),
                    autofocus: isTv),
                row(Icons.description_outlined, 'Terms & Conditions',
                    () => open('Terms & Conditions', Future.value(_blocks(kTerms)))),
                row(Icons.code, 'Open-source licenses',
                    () => open('Open-source licenses', _licenses())),
                const SizedBox(height: 6),
                const Text(
                  'Works offline. Needs no accessories, no permissions and no sign-in.\n'
                  'Privacy Policy & Terms last updated $kLastUpdated',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Pal.dim, fontSize: 13),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Scrollable text page. D-pad Up/Down scroll it (no focusable children needed).
class DocPage extends StatefulWidget {
  const DocPage({super.key, required this.title, required this.blocks});
  final String title;
  final Future<List<String>> blocks;
  @override
  State<DocPage> createState() => _DocPageState();
}

class _DocPageState extends State<DocPage> {
  final ScrollController sc = ScrollController();

  @override
  void dispose() {
    sc.dispose();
    super.dispose();
  }

  void _scroll(double d) {
    if (!sc.hasClients) return;
    sc.animateTo(
      (sc.offset + d).clamp(0.0, sc.position.maxScrollExtent),
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut,
    );
  }

  KeyEventResult _onKey(FocusNode n, KeyEvent e) {
    if (e is! KeyDownEvent && e is! KeyRepeatEvent) return KeyEventResult.ignored;
    final k = e.logicalKey;
    if (k == LogicalKeyboardKey.arrowDown) {
      _scroll(260);
    } else if (k == LogicalKeyboardKey.arrowUp) {
      _scroll(-260);
    } else if (k == LogicalKeyboardKey.pageDown) {
      _scroll(600);
    } else if (k == LogicalKeyboardKey.pageUp) {
      _scroll(-600);
    } else {
      return KeyEventResult.ignored;
    }
    return KeyEventResult.handled;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      body: SafeArea(
        child: Focus(
          autofocus: true,
          onKeyEvent: _onKey,
          child: Padding(
            padding: EdgeInsets.fromLTRB(isTv ? 48 : 12, 4, isTv ? 48 : 12, 16),
            child: Glass(
              radius: 28,
              blur: panelBlur,
              child: FutureBuilder<List<String>>(
                future: widget.blocks,
                builder: (context, snap) {
                  final data = snap.data;
                  if (data == null) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  return ListView.builder(
                    controller: sc,
                    padding: const EdgeInsets.all(22),
                    itemCount: data.length,
                    itemBuilder: (context, i) => Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: Text(
                        data[i],
                        style: TextStyle(
                            fontSize: isTv ? 20 : 16,
                            height: 1.45,
                            color: Pal.text),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
