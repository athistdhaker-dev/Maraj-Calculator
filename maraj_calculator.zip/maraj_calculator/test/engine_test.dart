import 'package:flutter_test/flutter_test.dart';
import 'package:maraj_calculator/converter.dart';
import 'package:maraj_calculator/core.dart';
import 'package:maraj_calculator/engine.dart';
import 'package:maraj_calculator/programmer.dart';

double ev(String s, {bool deg = true, double ans = 0}) =>
    Evaluator(degrees: deg, ans: ans).eval(s);

void main() {
  test('arithmetic and precedence', () {
    expect(ev('2+3×4'), 14);
    expect(ev('(2+3)×4'), 20);
    expect(ev('10÷4'), 2.5);
    expect(ev('-2^2'), -4);
    expect(ev('2^3^2'), 512);
    expect(ev('2^-1'), 0.5);
    expect(ev('5!'), 120);
    expect(ev('17 mod 5'), 2);
  });

  test('implicit multiplication and auto-closing parentheses', () {
    expect(ev('2(3+4)'), 14);
    expect(ev('2π'), closeTo(6.283185307, 1e-8));
    expect(ev('sin(30'), closeTo(0.5, 1e-12));
    expect(ev('√16'), 4);
    expect(ev('√(16)'), 4);
  });

  test('percent', () {
    expect(ev('50%'), 0.5);
    expect(ev('200+10%'), 220);
    expect(ev('200−10%'), 180);
    expect(ev('200×10%'), 20);
  });

  test('trigonometry degrees / radians', () {
    expect(ev('sin(30)'), closeTo(0.5, 1e-12));
    expect(ev('sin(180)'), 0);
    expect(ev('cos(90)'), 0);
    expect(ev('tan(45)'), closeTo(1, 1e-12));
    expect(ev('asin(1)'), closeTo(90, 1e-9));
    expect(ev('sin(pi/2)', deg: false), closeTo(1, 1e-12));
    expect(() => ev('tan(90)'), throwsA(isA<CalcError>()));
  });

  test('functions', () {
    expect(ev('ln(e)'), closeTo(1, 1e-12));
    expect(ev('log(1000)'), closeTo(3, 1e-12));
    expect(ev('log2(8)'), closeTo(3, 1e-12));
    expect(ev('cbrt(27)'), 3);
    expect(ev('abs(−5)'), 5);
    expect(ev('ncr(5,2)'), 10);
    expect(ev('npr(5,2)'), 20);
    expect(ev('tanh(0)'), 0);
    expect(ev('2×ans', ans: 21), 42);
  });

  test('errors', () {
    expect(() => ev('1÷0'), throwsA(isA<CalcError>()));
    expect(() => ev('5+'), throwsA(isA<CalcError>()));
    expect(() => ev('√(−1)'), throwsA(isA<CalcError>()));
    expect(() => ev('2..3'), throwsA(isA<CalcError>()));
  });

  test('formatting', () {
    expect(fmt(0.1 + 0.2), '0.3');
    expect(fmt(100), '100');
    expect(fmt(1234.5), '1234.5');
    expect(fmt(1e21), '1E21');
    expect(fmt(-0.0), '0');
  });

  test('scientific controller', () {
    final c = SciController();
    for (final t in ['2', '+', '3', '×', '4']) {
      c.press(t);
    }
    expect(c.preview, '14');
    c.equals();
    expect(c.expr, '14');
    c.press('+');
    c.press('1');
    c.equals();
    expect(c.expr, '15');
    expect(c.history.length, 2);
    c.clear();
    c.press('sin(');
    c.backspace();
    expect(c.expr, '');
  });

  test('programmer', () {
    final p = ProgController();
    p.setBase(16);
    p.digit(15);
    p.digit(15);
    expect(p.cur, 255);
    p.setBase(10);
    expect(p.mainText, '255');
    p.setOp('AND');
    p.digit(1);
    p.digit(5);
    p.equals();
    expect(p.cur, 15);
    p.clear();
    p.not();
    expect(p.cur, -1);
    p.setBase(16);
    expect(p.mainText, 'FFFF FFFF FFFF FFFF');
  });

  test('converter', () {
    final c = ConvController();
    c.setCat(0);
    c.from = 3; // km
    c.to = 2; // m
    c.input = '1';
    expect(c.result, 1000);
    c.setCat(2); // temperature
    c.from = 0;
    c.to = 1;
    c.input = '100';
    expect(c.result, closeTo(212, 1e-9));
  });
}
