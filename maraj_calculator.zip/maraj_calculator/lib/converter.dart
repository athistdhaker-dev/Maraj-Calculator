import 'package:flutter/foundation.dart';
import 'engine.dart';

class Unit {
  const Unit(this.name, this.sym, this.f);
  final String name, sym;
  final double f; // factor to the category's base unit
}

class Category {
  const Category(this.name, this.units,
      {this.from = 0, this.to = 1, this.temp = false});
  final String name;
  final List<Unit> units;
  final int from, to;
  final bool temp;
}

const categories = <Category>[
  Category('Length', [
    Unit('Millimetre', 'mm', 0.001),
    Unit('Centimetre', 'cm', 0.01),
    Unit('Metre', 'm', 1),
    Unit('Kilometre', 'km', 1000),
    Unit('Inch', 'in', 0.0254),
    Unit('Foot', 'ft', 0.3048),
    Unit('Yard', 'yd', 0.9144),
    Unit('Mile', 'mi', 1609.344),
    Unit('Nautical mile', 'nmi', 1852),
  ], from: 2, to: 5),
  Category('Mass', [
    Unit('Milligram', 'mg', 0.000001),
    Unit('Gram', 'g', 0.001),
    Unit('Kilogram', 'kg', 1),
    Unit('Tonne', 't', 1000),
    Unit('Ounce', 'oz', 0.028349523125),
    Unit('Pound', 'lb', 0.45359237),
    Unit('Stone', 'st', 6.35029318),
  ], from: 2, to: 5),
  Category('Temperature', [
    Unit('Celsius', '°C', 1),
    Unit('Fahrenheit', '°F', 1),
    Unit('Kelvin', 'K', 1),
  ], temp: true),
  Category('Area', [
    Unit('Square centimetre', 'cm²', 0.0001),
    Unit('Square metre', 'm²', 1),
    Unit('Hectare', 'ha', 10000),
    Unit('Square kilometre', 'km²', 1000000),
    Unit('Square inch', 'in²', 0.00064516),
    Unit('Square foot', 'ft²', 0.09290304),
    Unit('Acre', 'ac', 4046.8564224),
    Unit('Square mile', 'mi²', 2589988.110336),
  ], from: 1, to: 5),
  Category('Volume', [
    Unit('Millilitre', 'mL', 0.001),
    Unit('Litre', 'L', 1),
    Unit('Cubic metre', 'm³', 1000),
    Unit('Teaspoon', 'tsp', 0.00492892159375),
    Unit('Tablespoon', 'tbsp', 0.01478676478125),
    Unit('Fluid ounce', 'fl oz', 0.0295735295625),
    Unit('Cup', 'cup', 0.2365882365),
    Unit('Pint', 'pt', 0.473176473),
    Unit('Gallon', 'gal', 3.785411784),
  ], from: 1, to: 8),
  Category('Speed', [
    Unit('Metre/second', 'm/s', 1),
    Unit('Kilometre/hour', 'km/h', 1 / 3.6),
    Unit('Mile/hour', 'mph', 0.44704),
    Unit('Knot', 'kn', 0.514444444),
    Unit('Foot/second', 'ft/s', 0.3048),
  ], from: 1, to: 2),
  Category('Time', [
    Unit('Millisecond', 'ms', 0.001),
    Unit('Second', 's', 1),
    Unit('Minute', 'min', 60),
    Unit('Hour', 'h', 3600),
    Unit('Day', 'day', 86400),
    Unit('Week', 'wk', 604800),
    Unit('Year', 'yr', 31557600),
  ], from: 3, to: 2),
  Category('Data', [
    Unit('Bit', 'bit', 0.125),
    Unit('Byte', 'B', 1),
    Unit('Kilobyte', 'KB', 1024),
    Unit('Megabyte', 'MB', 1048576),
    Unit('Gigabyte', 'GB', 1073741824),
    Unit('Terabyte', 'TB', 1099511627776),
  ], from: 4, to: 3),
  Category('Pressure', [
    Unit('Pascal', 'Pa', 1),
    Unit('Kilopascal', 'kPa', 1000),
    Unit('Bar', 'bar', 100000),
    Unit('PSI', 'psi', 6894.757293168),
    Unit('Atmosphere', 'atm', 101325),
  ], from: 2, to: 3),
];

class ConvController extends ChangeNotifier {
  int cat = 0;
  int from = categories[0].from;
  int to = categories[0].to;
  String input = '0';

  Category get category => categories[cat];
  Unit get fromUnit => category.units[from];
  Unit get toUnit => category.units[to];

  void setCat(int i) {
    cat = i;
    from = categories[i].from;
    to = categories[i].to;
    notifyListeners();
  }

  void setFrom(int i) {
    from = i;
    notifyListeners();
  }

  void setTo(int i) {
    to = i;
    notifyListeners();
  }

  void swap() {
    final t = from;
    from = to;
    to = t;
    notifyListeners();
  }

  void key(String k) {
    if (k == '.') {
      if (input.contains('.')) return;
      input = '$input.';
    } else if (input == '0') {
      input = k == '00' ? '0' : k;
    } else if (input == '-0') {
      input = k == '00' ? '-0' : '-$k';
    } else {
      if (input.length >= 15) return;
      input = '$input$k';
    }
    notifyListeners();
  }

  void negate() {
    if (input == '0') return;
    input = input.startsWith('-') ? input.substring(1) : '-$input';
    notifyListeners();
  }

  void backspace() {
    if (input.length <= 1 || (input.length == 2 && input.startsWith('-'))) {
      input = '0';
    } else {
      input = input.substring(0, input.length - 1);
    }
    notifyListeners();
  }

  void clear() {
    input = '0';
    notifyListeners();
  }

  double? get value => double.tryParse(input);

  double? get result {
    final v = value;
    if (v == null) return null;
    if (category.temp) {
      double c;
      switch (fromUnit.sym) {
        case '°F':
          c = (v - 32) * 5 / 9;
          break;
        case 'K':
          c = v - 273.15;
          break;
        default:
          c = v;
      }
      switch (toUnit.sym) {
        case '°F':
          return c * 9 / 5 + 32;
        case 'K':
          return c + 273.15;
        default:
          return c;
      }
    }
    return v * fromUnit.f / toUnit.f;
  }

  String get resultText {
    final r = result;
    return r == null ? '—' : fmt(r);
  }
}
