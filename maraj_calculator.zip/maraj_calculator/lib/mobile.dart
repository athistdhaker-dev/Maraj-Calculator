import 'package:flutter/material.dart';

import 'core.dart';
import 'glass.dart';
import 'pages.dart';
import 'ui.dart';

class MobileHome extends StatefulWidget {
  const MobileHome({super.key});
  @override
  State<MobileHome> createState() => _MobileHomeState();
}

class _MobileHomeState extends State<MobileHome> {
  final Models m = Models();
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: false,
      body: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
          child: IndexedStack(
            index: tab,
            children: <Widget>[
              SciPanel(c: m.sci),
              ProgPanel(c: m.prog),
              ConvPanel(c: m.conv),
              HistoryPanel(
                c: m.sci,
                onPick: (h) {
                  m.sci.press(h.result);
                  setState(() => tab = 0);
                },
              ),
              const InfoPanel(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 4, 10, 6),
          child: Glass(
            radius: 30,
            blur: panelBlur,
            child: NavigationBar(
              selectedIndex: tab,
              height: 62,
              backgroundColor: Colors.transparent,
              surfaceTintColor: Colors.transparent,
              shadowColor: Colors.transparent,
              elevation: 0,
              indicatorColor: const Color(0x44FFFFFF),
              labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
              onDestinationSelected: (i) => setState(() => tab = i),
              destinations: const <NavigationDestination>[
                NavigationDestination(
                    icon: Icon(Icons.calculate_outlined),
                    selectedIcon: Icon(Icons.calculate),
                    label: 'Scientific'),
                NavigationDestination(icon: Icon(Icons.code), label: 'Program'),
                NavigationDestination(icon: Icon(Icons.swap_horiz), label: 'Convert'),
                NavigationDestination(icon: Icon(Icons.history), label: 'History'),
                NavigationDestination(icon: Icon(Icons.info_outline), label: 'About'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
