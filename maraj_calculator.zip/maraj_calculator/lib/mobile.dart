import 'package:flutter/material.dart';

import 'core.dart';
import 'ui.dart';

class MobileHome extends StatefulWidget {
  const MobileHome({super.key});
  @override
  State<MobileHome> createState() => _MobileHomeState();
}

class _MobileHomeState extends State<MobileHome> {
  final Models m = Models();
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 6, 6, 0),
          child: IndexedStack(
            index: tab,
            children: <Widget>[
              SciPanel(c: m.sci),
              ProgPanel(c: m.prog),
              ConvPanel(c: m.conv),
              HistoryPanel(
                c: m.sci,
                onPick: (h) {
                  m.sci.press(h.result);
                  setState(() => tab = 0);
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        height: 64,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const <NavigationDestination>[
          NavigationDestination(
              icon: Icon(Icons.calculate_outlined),
              selectedIcon: Icon(Icons.calculate),
              label: 'Scientific'),
          NavigationDestination(
              icon: Icon(Icons.code), label: 'Programmer'),
          NavigationDestination(
              icon: Icon(Icons.swap_horiz), label: 'Convert'),
          NavigationDestination(
              icon: Icon(Icons.history), label: 'History'),
        ],
      ),
    );
  }
}
