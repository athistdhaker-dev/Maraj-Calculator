# Maraj Calculator - Scientific / Programmer / Converter (Phone + Jio STB)
One Flutter codebase, two purpose-built UIs, same build pipeline as Maraj Wallpaper.

| | TV / Jio STB (`TARGET=tv`) | Mobile (`TARGET=mobile`) |
|---|---|---|
| Layout | Left rail + big keypad, TV safe margins | Bottom navigation, portrait + landscape |
| Input | D-pad (arrows move, OK presses). Remote number keys also work | Touch; physical keyboard works too |
| Manifest | Leanback launcher + banner, no touchscreen needed | Normal launcher |
| Permissions | none | none |

## Features
- **Scientific**: + − × ÷ ^ % ! mod, brackets, implicit multiply (`2π`, `2(3+4)`), auto-closing brackets,
  sin cos tan (+ inverse via 2nd), sinh cosh tanh, ln log log2 √ ∛ eˣ 10ˣ x² x³ 1/x, nCr nPr abs,
  π e Ans, DEG/RAD, memory (MC MR M+ M−), live result preview, `200+10%` = 220 style percent.
- **Programmer**: HEX / DEC / OCT / BIN (64-bit), AND OR XOR NOT << >> MOD, all bases shown live.
- **Convert**: Length, Mass, Temperature, Area, Volume, Speed, Time, Data, Pressure.
- **History**: last 200 calculations, tap to reuse.

## Build (GitHub Actions)
1. Create a NEW GitHub repo.
2. Put `build-apk.yml` at `.github/workflows/build-apk.yml`.
3. Upload `maraj_calculator.zip` to the repo root. The workflow builds and publishes a Release with
   `MarajCalculator-TV-*.apk`, `-Mobile-arm64-v8a-`, `-Mobile-armeabi-v7a-`, `-Mobile-x86_64-`, `-Mobile-universal-`.

Local:
    flutter create --platforms=android --org com.maraj --project-name maraj_calculator .
    rm -f test/widget_test.dart
    flutter test
    python3 tools/patch_manifest.py tv      # or: mobile
    flutter build apk --release --dart-define=TARGET=tv

## Signing
APKs are signed with `tools/maraj-calc-sideload.jks` (a key made only for this app, public in the repo, fine for
sideloading). For JioStore / Play Store set your OWN private key via repo secrets
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` and never publish it.

## Ideas for next version
EMI / GST / discount calculators, saved history (shared_preferences), themes, date calculator.
