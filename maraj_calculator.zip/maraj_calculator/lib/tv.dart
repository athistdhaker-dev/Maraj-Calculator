import 'package:flutter/material.dart';

import 'core.dart';
import 'ui.dart';

/// TV / Jio STB layout: left rail + big D-pad friendly panel.
class TvHome extends StatefulWidget {
  const TvHome({super.key});
  @override
  State<TvHome> createState() => _TvHomeState();
}

class _TvHomeState extends State<TvHome> {
  final Models m = Models();
  int tab = 0;

  static const _items = <List<Object>>[
    <Object>['Scientific', Icons.calculate],
    <Object>['Programmer', Icons.code],
    <Object>['Convert', Icons.swap_horiz],
    <Object>['History', Icons.history],
  ];

  Widget _panel() {
    switch (tab) {
      case 1:
        return ProgPanel(c: m.prog);
      case 2:
        return ConvPanel(c: m.conv);
      case 3:
        return HistoryPanel(
          c: m.sci,
          onPick: (h) {
            m.sci.press(h.result);
            setState(() => tab = 0);
          },
        );
      default:
        return SciPanel(c: m.sci);
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Padding(
        // TV safe margins (overscan)
        padding: EdgeInsets.symmetric(
            horizontal: size.width * 0.04, vertical: size.height * 0.05),
        child: Row(
          children: <Widget>[
            SizedBox(
              width: size.width * 0.19,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const Padding(
                    padding: EdgeInsets.fromLTRB(8, 0, 8, 16),
                    child: Text('Maraj\nCalculator',
                        style: TextStyle(
                            fontSize: 26,
                            height: 1.1,
                            fontWeight: FontWeight.w700,
                            color: Pal.eq)),
                  ),
                  for (var i = 0; i < _items.length; i++)
                    NavItem(
                      label: _items[i][0] as String,
                      icon: _items[i][1] as IconData,
                      selected: tab == i,
                      onTap: () => setState(() => tab = i),
                    ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.all(8),
                    child: Text('◀ ▶ ▲ ▼ move   OK press',
                        style: TextStyle(color: Pal.dim, fontSize: 13)),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 18),
            Expanded(child: _panel()),
          ],
        ),
      ),
    );
  }
}

class NavItem extends StatefulWidget {
  const NavItem({
    super.key,
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  @override
  State<NavItem> createState() => _NavItemState();
}

class _NavItemState extends State<NavItem> {
  bool _focus = false;

  @override
  Widget build(BuildContext context) {
    final sel = widget.selected;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: FocusableActionDetector(
        onShowFocusHighlight: (v) => setState(() => _focus = v),
        actions: <Type, Action<Intent>>{
          ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (_) {
            widget.onTap();
            return null;
          }),
        },
        child: GestureDetector(
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            decoration: BoxDecoration(
              color: sel ? Pal.keyFn : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: _focus ? Colors.white : Colors.transparent, width: 3),
            ),
            child: Row(
              children: <Widget>[
                Icon(widget.icon, color: sel ? Pal.eq : Pal.dim, size: 24),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(widget.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: sel ? Pal.text : Pal.dim)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
