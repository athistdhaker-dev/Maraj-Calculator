"""Usage: python3 tools/patch_manifest.py tv|mobile   (run after `flutter create`)
Safe to run repeatedly: it always starts from the original generated manifest."""
import re, shutil, sys, pathlib

target = sys.argv[1] if len(sys.argv) > 1 else "tv"
assert target in ("tv", "mobile"), "target must be tv or mobile"

p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
orig = p.with_name("AndroidManifest.xml.orig")
if orig.exists():
    shutil.copy(orig, p)
else:
    shutil.copy(p, orig)

s = p.read_text(encoding="utf-8")
# The calculator needs no permissions at all (no internet, no storage).
feats = []
app_attr = ""
if target == "tv":
    feats += [
        '<uses-feature android:name="android.software.leanback" android:required="false"/>',
        '<uses-feature android:name="android.hardware.touchscreen" android:required="false"/>',
    ]
    app_attr = ' android:banner="@drawable/banner"'

s = s.replace("<application", "\n    ".join(feats) + "\n    <application" + app_attr, 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Maraj Calculator"', s, 1)
if target == "tv":
    s = s.replace(
        '<category android:name="android.intent.category.LAUNCHER"/>',
        '<category android:name="android.intent.category.LAUNCHER"/>\n'
        '                <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>', 1)
p.write_text(s, encoding="utf-8")

shutil.copytree("assets/android_icons", "android/app/src/main/res", dirs_exist_ok=True)

# Native helper: TV detection + low-RAM detection
for f in pathlib.Path("android/app/src/main").rglob("MainActivity.kt"):
    pkg = re.search(r"^package\s+([\w.]+)", f.read_text(), re.M).group(1)
    f.write_text(f"""package {pkg}

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {{
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "maraj/device")
            .setMethodCallHandler {{ call, result ->
                when (call.method) {{
                    "lowEnd" -> {{
                        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                        result.success(am.isLowRamDevice || am.memoryClass < 192)
                    }}
                    "isTv" -> {{
                        val um = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
                        result.success(um.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION)
                    }}
                    else -> result.notImplemented()
                }}
            }}
    }}
}}
""")
print(f"patched for {target}")
