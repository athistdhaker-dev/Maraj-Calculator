// Pure Dart expression engine (no Flutter imports) so it can be unit-tested.
import 'dart:math' as math;

class CalcError implements Exception {
  CalcError(this.message);
  final String message;
  @override
  String toString() => message;
}

enum _T { num, id, op, lp, rp, comma, end }

class _Tok {
  _Tok(this.t, this.s, [this.v = 0]);
  final _T t;
  final String s;
  final double v;
}

/// Formats a result with up to 12 significant digits, no trailing zeros.
String fmt(double v) {
  if (v.isNaN) return 'Error';
  if (v.isInfinite) return v < 0 ? '-∞' : '∞';
  if (v == 0) return '0';
  var s = v.toStringAsPrecision(12);
  if (s.contains('e')) {
    final parts = s.split('e');
    var m = parts[0];
    if (m.contains('.')) {
      m = m.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    }
    var ex = parts[1];
    if (ex.startsWith('+')) ex = ex.substring(1);
    return '${m}E$ex';
  }
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
  return s;
}

/// Recursive-descent evaluator.
/// Supports + - × ÷ ^ ! % mod, ( ), implicit multiplication, constants
/// (pi e ans) and functions (sin cos tan asin acos atan sinh cosh tanh ln log
/// log2 sqrt cbrt abs exp floor ceil round fact ncr npr).
class Evaluator {
  Evaluator({this.degrees = true, this.ans = 0});

  final bool degrees;
  final double ans;

  List<_Tok> _toks = <_Tok>[];
  int _p = 0;

  double eval(String src) {
    _toks = _lex(src);
    _p = 0;
    if (_toks.length == 1) throw CalcError('Empty');
    final v = _expr();
    if (_peek.t != _T.end) throw CalcError('Syntax error');
    if (v.isNaN) throw CalcError('Invalid input');
    if (v.isInfinite) throw CalcError('Overflow');
    return v;
  }

  // ------------------------------------------------------------------ lexer
  static bool _digit(int c) => c >= 48 && c <= 57;
  static bool _letter(int c) => (c >= 65 && c <= 90) || (c >= 97 && c <= 122);

  List<_Tok> _lex(String src) {
    final out = <_Tok>[];
    var i = 0;
    final n = src.length;
    while (i < n) {
      final ch = src[i];
      final c = src.codeUnitAt(i);
      if (ch == ' ') {
        i++;
        continue;
      }
      if (_digit(c) || ch == '.') {
        var j = i;
        var seenDot = false;
        while (j < n && (_digit(src.codeUnitAt(j)) || src[j] == '.')) {
          if (src[j] == '.') {
            if (seenDot) throw CalcError('Syntax error');
            seenDot = true;
          }
          j++;
        }
        if (j < n && src[j] == 'E') {
          var k = j + 1;
          if (k < n && (src[k] == '+' || src[k] == '-')) k++;
          if (k < n && _digit(src.codeUnitAt(k))) {
            while (k < n && _digit(src.codeUnitAt(k))) {
              k++;
            }
            j = k;
          }
        }
        final text = src.substring(i, j);
        final v = double.tryParse(text);
        if (v == null) throw CalcError('Syntax error');
        out.add(_Tok(_T.num, text, v));
        i = j;
        continue;
      }
      if (_letter(c)) {
        var j = i;
        while (j < n && _letter(src.codeUnitAt(j))) {
          j++;
        }
        var name = src.substring(i, j);
        if (name == 'log' && j < n && src[j] == '2') {
          name = 'log2';
          j++;
        }
        out.add(_Tok(_T.id, name));
        i = j;
        continue;
      }
      switch (ch) {
        case '+':
          out.add(_Tok(_T.op, '+'));
          break;
        case '-':
        case '−':
          out.add(_Tok(_T.op, '-'));
          break;
        case '*':
        case '×':
        case '·':
          out.add(_Tok(_T.op, '*'));
          break;
        case '/':
        case '÷':
          out.add(_Tok(_T.op, '/'));
          break;
        case '^':
        case '!':
        case '%':
        case '√':
          out.add(_Tok(_T.op, ch));
          break;
        case '(':
          out.add(_Tok(_T.lp, ch));
          break;
        case ')':
          out.add(_Tok(_T.rp, ch));
          break;
        case ',':
          out.add(_Tok(_T.comma, ch));
          break;
        case 'π':
          out.add(_Tok(_T.id, 'pi'));
          break;
        default:
          throw CalcError('Syntax error');
      }
      i++;
    }
    out.add(_Tok(_T.end, ''));
    return out;
  }

  // ----------------------------------------------------------------- parser
  _Tok get _peek => _toks[_p];
  _Tok _next() => _toks[_p++];
  bool _isOp(String s) => _peek.t == _T.op && _peek.s == s;

  double _expr() {
    var v = _term();
    while (_peek.t == _T.op && (_peek.s == '+' || _peek.s == '-')) {
      final op = _next().s;
      final start = _p;
      var r = _term();
      // "200 + 10%" means 200 + (10% of 200)
      if (_p - start == 2 &&
          _toks[start].t == _T.num &&
          _toks[_p - 1].t == _T.op &&
          _toks[_p - 1].s == '%') {
        r = v * r;
      }
      v = op == '+' ? v + r : v - r;
    }
    return v;
  }

  bool _startsOperand() {
    final t = _peek;
    if (t.t == _T.num || t.t == _T.lp) return true;
    if (t.t == _T.id && t.s != 'mod') return true;
    return t.t == _T.op && t.s == '√';
  }

  double _term() {
    var v = _unary();
    while (true) {
      if (_peek.t == _T.op && (_peek.s == '*' || _peek.s == '/')) {
        final op = _next().s;
        final r = _unary();
        if (op == '/') {
          if (r == 0) throw CalcError('Cannot divide by zero');
          v = v / r;
        } else {
          v = v * r;
        }
      } else if (_peek.t == _T.id && _peek.s == 'mod') {
        _next();
        final r = _unary();
        if (r == 0) throw CalcError('Cannot divide by zero');
        v = v % r;
      } else if (_startsOperand()) {
        v = v * _power();
      } else {
        return v;
      }
    }
  }

  double _unary() {
    if (_isOp('-')) {
      _next();
      return -_unary();
    }
    if (_isOp('+')) {
      _next();
      return _unary();
    }
    return _power();
  }

  double _power() {
    final base = _postfix();
    if (_isOp('^')) {
      _next();
      final ex = _unary();
      return math.pow(base, ex).toDouble();
    }
    return base;
  }

  double _postfix() {
    var v = _primary();
    while (_peek.t == _T.op && (_peek.s == '!' || _peek.s == '%')) {
      final op = _next().s;
      v = op == '!' ? _fact(v) : v / 100;
    }
    return v;
  }

  void _closeParen() {
    if (_peek.t == _T.rp) {
      _next();
    } else if (_peek.t != _T.end) {
      throw CalcError('Syntax error');
    }
  }

  double _primary() {
    final t = _next();
    if (t.t == _T.num) return t.v;
    if (t.t == _T.lp) {
      final v = _expr();
      _closeParen();
      return v;
    }
    if (t.t == _T.id) return _ident(t.s);
    if (t.t == _T.op && t.s == '√') return _sqrt(_postfix());
    throw CalcError('Syntax error');
  }

  double _ident(String name) {
    if (name == 'pi') return math.pi;
    if (name == 'e') return math.e;
    if (name == 'ans') return ans;
    if (_peek.t != _T.lp) throw CalcError('Syntax error');
    _next();
    final args = <double>[_expr()];
    while (_peek.t == _T.comma) {
      _next();
      args.add(_expr());
    }
    _closeParen();
    return _call(name, args);
  }

  // -------------------------------------------------------------- functions
  double _toRad(double x) => degrees ? x * math.pi / 180 : x;
  double _fromRad(double x) => degrees ? x * 180 / math.pi : x;
  double _clean(double x) => x.abs() < 1e-15 ? 0 : x;

  double _sqrt(double x) {
    if (x < 0) throw CalcError('Invalid input');
    return math.sqrt(x);
  }

  double _fact(double x) {
    if (x < 0 || x != x.floorToDouble()) throw CalcError('Invalid input');
    if (x > 170) throw CalcError('Overflow');
    var r = 1.0;
    for (var i = 2; i <= x; i++) {
      r *= i;
    }
    return r;
  }

  void _needInt(double x) {
    if (x < 0 || x != x.floorToDouble()) throw CalcError('Invalid input');
  }

  double _call(String f, List<double> a) {
    if (f == 'ncr' || f == 'npr') {
      if (a.length != 2) throw CalcError('Syntax error');
      final n = a[0];
      final k = a[1];
      _needInt(n);
      _needInt(k);
      if (k > n) throw CalcError('Invalid input');
      if (f == 'npr') {
        var r = 1.0;
        for (var i = 0; i < k; i++) {
          r *= (n - i);
        }
        return r;
      }
      final kk = math.min(k, n - k);
      var r = 1.0;
      for (var i = 1; i <= kk; i++) {
        r = r * (n - kk + i) / i;
      }
      return r.roundToDouble();
    }
    if (a.length != 1) throw CalcError('Syntax error');
    final x = a[0];
    switch (f) {
      case 'sin':
        return _clean(math.sin(_toRad(x)));
      case 'cos':
        return _clean(math.cos(_toRad(x)));
      case 'tan':
        if (degrees && ((x % 180) - 90).abs() < 1e-9) {
          throw CalcError('Undefined');
        }
        return _clean(math.tan(_toRad(x)));
      case 'asin':
        if (x < -1 || x > 1) throw CalcError('Invalid input');
        return _fromRad(math.asin(x));
      case 'acos':
        if (x < -1 || x > 1) throw CalcError('Invalid input');
        return _fromRad(math.acos(x));
      case 'atan':
        return _fromRad(math.atan(x));
      case 'sinh':
        return (math.exp(x) - math.exp(-x)) / 2;
      case 'cosh':
        return (math.exp(x) + math.exp(-x)) / 2;
      case 'tanh':
        if (x > 20) return 1;
        if (x < -20) return -1;
        final e2 = math.exp(2 * x);
        return (e2 - 1) / (e2 + 1);
      case 'ln':
        if (x <= 0) throw CalcError('Invalid input');
        return math.log(x);
      case 'log':
        if (x <= 0) throw CalcError('Invalid input');
        return math.log(x) / math.ln10;
      case 'log2':
        if (x <= 0) throw CalcError('Invalid input');
        return math.log(x) / math.ln2;
      case 'sqrt':
        return _sqrt(x);
      case 'cbrt':
        final r = (x < 0 ? -1 : 1) * math.pow(x.abs(), 1 / 3).toDouble();
        final rr = r.roundToDouble();
        return rr * rr * rr == x ? rr : r;
      case 'abs':
        return x.abs();
      case 'exp':
        return math.exp(x);
      case 'floor':
        return x.floorToDouble();
      case 'ceil':
        return x.ceilToDouble();
      case 'round':
        return x.roundToDouble();
      case 'fact':
        return _fact(x);
    }
    throw CalcError('Unknown function $f');
  }
}
