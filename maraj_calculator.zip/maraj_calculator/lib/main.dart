import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core.dart';
import 'mobile.dart';
import 'tv.dart';
import 'ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await detectTarget();
  if (isTv) {
    await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }
  runApp(const CalcApp());
}

class CalcApp extends StatelessWidget {
  const CalcApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Maraj Calculator',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
              seedColor: Pal.eq, brightness: Brightness.dark),
          scaffoldBackgroundColor: Colors.transparent,
          navigationBarTheme: const NavigationBarThemeData(
            backgroundColor: Color(0xFF101626),
          ),
        ),
        builder: (context, child) => Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[Pal.bg1, Pal.bg2],
            ),
          ),
          child: child,
        ),
        home: isTv ? const TvHome() : const MobileHome(),
      );
}
