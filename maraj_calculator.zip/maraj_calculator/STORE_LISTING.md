# JioStore STB submission - Maraj Calculator
(Prepared from the Jio guideline PDFs + JioAppValidationGuidelines.xlsx)

## Developer account (you must do this yourself on the JioStore portal)
Company: official email, company TIN scan (<500 KB), digitally signed SSD (PDF).
Individual: govt ID scan (<500 KB, NOT Aadhaar), no special characters in names.

## App info (limits from Jio guideline)
- **App name** (3-24 chars): Maraj Calculator
- **Keywords** (5-15): calculator, scientific calculator, programmer calculator, unit converter, hex, binary, math, trigonometry, percentage, tv calculator
- **Short description** (3-100): Scientific and programmer calculator with unit converter, made for your TV remote.
- **Long description** (200-2000):
  Maraj Calculator brings a powerful calculator to your TV and phone. Use the Scientific mode for brackets, powers, roots, percentages, factorials, trigonometry (degrees or radians), logarithms, permutations and combinations, memory keys and a live result preview. Switch to Programmer mode for 64-bit HEX, DEC, OCT and BIN with AND, OR, XOR, NOT and shift operations, all bases shown at once. The Convert tab handles length, mass, temperature, area, volume, speed, time, data and pressure. Every calculation is saved in History so you can reuse it. The whole app is designed for the Jio remote: move with the arrow keys and press OK. It works fully offline, needs no sign-in, no permissions and shows no ads. Privacy Policy, Terms and open-source licenses are available inside the app under "About & Legal".
- **Category**: Utilities / Tools (pick the closest in the portal)
- **Age rating**: 3
- **Support email / Publisher name**: fill in (mandatory)
- **Privacy Policy & T&C links**: mandatory - edit the placeholders in `lib/legal.dart` (publisher, grievance officer name, mobile, address, email) and also host the same text online. They are already reachable on the STB: About & Legal.

## Assets (store_assets/) - all opaque, exact sizes
| Asset | File | Status |
|---|---|---|
| App icon 320x180 | app_icon_320x180.png | generated |
| Promo image 1920x1080 | promo_image_1920x1080.png | generated |
| Carousel 1920x720 | carousel_1920x720.png | generated, content inside the 1628x382 core area |
| Recommendation icon 360x442 | recommendation_icon_360x442.png | generated |
| Screenshots 1920x1080 x5 | - | **You must capture these** from the emulator or the STB (see below) |
| Promo video .mp4 <=50 MB | - | optional, not made |

Screenshots: create an Android TV (1080p) AVD **without Play Store**, API 28, RAM 1-2 GB, 8 GB storage, disable Google Play services + Google Services Framework, install the TV APK, then take 5 shots: Scientific, Programmer, Convert, History, About & Legal.

## Device facts used (from DeviceSpecifications.pdf)
Android 9+, 1 GB or 2 GB RAM, 8 GB flash, OpenGL ES 2/3, remote = D-pad + OK + Back (no touch).
So: D-pad only UI, GPU-light glass (blur is switched off automatically on low-RAM boxes), no GMS.

## Self-certification (honest status)
| Item | Answer |
|---|---|
| CPU < 50% foreground | **Measure** on device: `adb shell top -m 5` while pressing keys |
| Responsiveness < 5 s | Expected yes, **measure** cold start |
| Minimum permissions | Yes - the app requests **no** permissions |
| Security / encrypted data | Yes - nothing is stored or sent (offline app) |
| 24 h stability (Monkey) | **Not done.** `adb shell monkey -p com.maraj.maraj_calculator --throttle 300 -v 500000` |
| GMS dependency | No |
| Android M (API 23) compatible | **No** - Flutter's minSdk is 24 (STB runs Android 9+, so fine) |
| Leanback | Partly - leanback launcher + banner + D-pad UI, built with Flutter (not Leanback framework) |
| Voice search (local / global) | No (not applicable for a calculator) |
| Native libs | Only Flutter engine libs (libflutter.so, libapp.so) |
| Static analysis | CI runs `flutter analyze` (informational) |
| Pro-guard | R8 + Dart `--obfuscate` in CI build |
| Log level | No logging in release |
| Data storage / 20% rule | Not applicable - app never writes files |
| Accessories | None (remote only) |
| Boot-up impact | None (no boot receiver/service) |
| Security audit | **Not done** |
| Privacy policy / T&C / Licenses screens | Yes (About & Legal) - fill the placeholders |
| RAM / ROM | **Measure**: `adb shell dumpsys meminfo com.maraj.maraj_calculator`; ROM = APK size |
| Published on Google Play | No |
| Upgrade tested | **Test**: `adb install -r` new build over old (same signing key required) |
| Hidden Google APIs / GMS / 3rd-party ad, payment SDKs | None |
| Custom keyboard | No |

## IntegrationChecks sheet
- Jio Ad SDK, Jio Push, Jio VA, Jio Analytics SDK: **not integrated.** These SDKs are downloaded from the JioStore developer portal and are native Android libraries. Answer "N" with comment "offline utility app, no ads / push / analytics / voice" unless Jio asks for them; if they do, send me the SDK docs and I will add them.
- Jio Cloud, Jio Payment: NA.
- Not allowed items (other ad SDK, GMS, other push, billing, analytics, Google Maps, other voice search): none present.

## Sanity checklist (Jio T1-T27) quick map
Install/uninstall, launch, splash (Flutter default launch screen), key navigation (D-pad), smooth scrolling (History, licenses), About screen with version (T26), exit with Back (T27). Sign-up / profile / video / search tests: not applicable (no accounts, no video). Mark "NA".

## Release signing
Before the real submission add your own private keystore as GitHub secrets (`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`). The bundled `tools/maraj-calc-sideload.jks` is public.
