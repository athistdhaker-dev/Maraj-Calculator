import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'converter.dart';
import 'core.dart';
import 'programmer.dart';

// ------------------------------------------------------------------ palette
class Pal {
  static const bg1 = Color(0xFF0B0F17);
  static const bg2 = Color(0xFF16203A);
  static const key = Color(0xFF1C2436);
  static const keyFn = Color(0xFF27334D);
  static const op = Color(0xFFFF9F43);
  static const eq = Color(0xFF2ED3B7);
  static const dangerBg = Color(0xFF3B2030);
  static const danger = Color(0xFFFF6B88);
  static const text = Color(0xFFEAF0FF);
  static const dim = Color(0xFF8D9AB5);
  static const dark = Color(0xFF0B0F17);
}

// -------------------------------------------------------------------- keys
enum KeyKind { num, fn, op, eq, danger }

class KeyDef {
  const KeyDef(this.label, this.onTap,
      {this.kind = KeyKind.num,
      this.autofocus = false,
      this.enabled = true,
      this.active = false});
  final String label;
  final VoidCallback onTap;
  final KeyKind kind;
  final bool autofocus, enabled, active;
}

class KeyBtn extends StatefulWidget {
  const KeyBtn(this.def, {super.key});
  final KeyDef def;
  @override
  State<KeyBtn> createState() => _KeyBtnState();
}

class _KeyBtnState extends State<KeyBtn> {
  bool _focus = false;
  bool _down = false;

  Color get _fill {
    switch (widget.def.kind) {
      case KeyKind.num:
        return Pal.key;
      case KeyKind.fn:
        return Pal.keyFn;
      case KeyKind.op:
        return Pal.op;
      case KeyKind.eq:
        return Pal.eq;
      case KeyKind.danger:
        return Pal.dangerBg;
    }
  }

  Color get _fg {
    switch (widget.def.kind) {
      case KeyKind.op:
      case KeyKind.eq:
        return Pal.dark;
      case KeyKind.danger:
        return Pal.danger;
      default:
        return Pal.text;
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.def;
    final len = d.label.length;
    final fs = (isTv ? 24.0 : 20.0) * (len > 4 ? 0.62 : (len > 2 ? 0.78 : 1.0));
    var fill = _fill;
    if (_down) fill = Color.lerp(fill, Colors.white, 0.18)!;
    if (!d.enabled) fill = Color.lerp(fill, Pal.bg1, 0.6)!;
    return Padding(
      padding: EdgeInsets.all(isTv ? 5 : 4),
      child: FocusableActionDetector(
        enabled: d.enabled,
        autofocus: d.autofocus,
        onShowFocusHighlight: (v) => setState(() => _focus = v),
        actions: <Type, Action<Intent>>{
          ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (_) {
            d.onTap();
            return null;
          }),
        },
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (_) => setState(() => _down = true),
          onTapUp: (_) => setState(() => _down = false),
          onTapCancel: () => setState(() => _down = false),
          onTap: d.enabled ? d.onTap : null,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: fill,
              borderRadius: BorderRadius.circular(isTv ? 14 : 16),
              border: Border.all(
                color: _focus
                    ? Colors.white
                    : (d.active ? Pal.op : Colors.transparent),
                width: _focus ? 3 : 2,
              ),
            ),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  d.label,
                  style: TextStyle(
                    fontSize: fs,
                    fontWeight: FontWeight.w600,
                    color: d.enabled ? _fg : Pal.dim,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

Widget keyGrid(List<List<KeyDef?>> rows) => Column(
      children: <Widget>[
        for (final r in rows)
          Expanded(
            child: Row(
              children: <Widget>[
                for (final k in r)
                  Expanded(child: k == null ? const SizedBox.shrink() : KeyBtn(k)),
              ],
            ),
          ),
      ],
    );

Widget chip(String text, {bool on = true}) => Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: on ? Pal.keyFn : Colors.transparent,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(text,
          style: TextStyle(
              fontSize: isTv ? 16 : 13,
              fontWeight: FontWeight.w600,
              color: on ? Pal.eq : Pal.dim)),
    );

// ----------------------------------------------------------- scientific tab
class SciDisplay extends StatelessWidget {
  const SciDisplay({super.key, required this.c, this.onToggleSci});
  final SciController c;
  final VoidCallback? onToggleSci;

  @override
  Widget build(BuildContext context) {
    final err = c.error;
    final main = c.expr.isEmpty ? '0' : c.expr;
    final pv = err ?? (c.preview != c.expr ? c.preview : '');
    return Container(
      margin: const EdgeInsets.fromLTRB(4, 4, 4, 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0x33000000),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Row(
            children: <Widget>[
              chip(c.degrees ? 'DEG' : 'RAD'),
              if (c.hasMemory) chip('M'),
              const Spacer(),
              if (onToggleSci != null)
                IconButton(
                  tooltip: 'Scientific keys',
                  padding: EdgeInsets.zero,
                  iconSize: 22,
                  constraints: const BoxConstraints(minWidth: 40, minHeight: 28),
                  icon: const Icon(Icons.functions, color: Pal.dim),
                  onPressed: onToggleSci,
                ),
            ],
          ),
          Expanded(
            child: Align(
              alignment: Alignment.bottomRight,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerRight,
                child: Text(
                  main,
                  maxLines: 1,
                  style: TextStyle(
                      fontSize: isTv ? 52 : 44,
                      fontWeight: FontWeight.w300,
                      color: Pal.text),
                ),
              ),
            ),
          ),
          SizedBox(
            height: isTv ? 40 : 34,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerRight,
              child: Text(
                pv,
                maxLines: 1,
                style: TextStyle(
                    fontSize: isTv ? 30 : 26,
                    color: err != null ? Pal.danger : Pal.dim),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SciPanel extends StatefulWidget {
  const SciPanel({super.key, required this.c});
  final SciController c;
  @override
  State<SciPanel> createState() => _SciPanelState();
}

class _SciPanelState extends State<SciPanel> {
  bool _showSci = false;
  SciController get c => widget.c;

  KeyDef _f(String label, String token) =>
      KeyDef(label, () => c.press(token), kind: KeyKind.fn);
  KeyDef _n(String label, {bool autofocus = false}) =>
      KeyDef(label, () => c.press(label), autofocus: autofocus);
  KeyDef _o(String label) => KeyDef(label, () => c.press(label), kind: KeyKind.op);

  List<List<KeyDef?>> _sciKeys() {
    final s = c.second;
    return <List<KeyDef?>>[
      <KeyDef?>[
        KeyDef('2nd', c.toggleSecond, kind: KeyKind.fn, active: s),
        _f('π', 'π'),
        _f('e', 'e'),
        _f('(', '('),
        _f(')', ')'),
      ],
      <KeyDef?>[
        _f(s ? 'sin⁻¹' : 'sin', s ? 'asin(' : 'sin('),
        _f(s ? 'cos⁻¹' : 'cos', s ? 'acos(' : 'cos('),
        _f(s ? 'tan⁻¹' : 'tan', s ? 'atan(' : 'tan('),
        _f('xʸ', '^'),
        _f('n!', '!'),
      ],
      <KeyDef?>[
        _f(s ? 'eˣ' : 'ln', s ? 'exp(' : 'ln('),
        _f(s ? '10ˣ' : 'log', s ? '10^' : 'log('),
        _f(s ? '∛' : '√', s ? 'cbrt(' : '√('),
        _f(s ? 'x³' : 'x²', s ? '^3' : '^2'),
        _f('1/x', '^(−1)'),
      ],
      <KeyDef?>[
        _f('abs', 'abs('),
        _f('nCr', 'ncr('),
        _f('nPr', 'npr('),
        _f('mod', ' mod '),
        _f(',', ','),
      ],
      <KeyDef?>[
        KeyDef('MC', c.memClear, kind: KeyKind.fn),
        KeyDef('MR', c.memRecall, kind: KeyKind.fn),
        KeyDef('M+', () => c.memAdd(1), kind: KeyKind.fn),
        KeyDef('M−', () => c.memAdd(-1), kind: KeyKind.fn),
        KeyDef(c.degrees ? 'DEG' : 'RAD', c.toggleAngle, kind: KeyKind.fn),
      ],
    ];
  }

  List<List<KeyDef?>> _basicKeys() => <List<KeyDef?>>[
        <KeyDef?>[
          KeyDef('AC', c.clear, kind: KeyKind.danger),
          KeyDef('⌫', c.backspace, kind: KeyKind.fn),
          _f('%', '%'),
          _o('÷'),
        ],
        <KeyDef?>[_n('7'), _n('8'), _n('9'), _o('×')],
        <KeyDef?>[_n('4'), _n('5', autofocus: isTv), _n('6'), _o('−')],
        <KeyDef?>[_n('1'), _n('2'), _n('3'), _o('+')],
        <KeyDef?>[
          _f('Ans', 'ans'),
          _n('0'),
          _n('.'),
          KeyDef('=', c.equals, kind: KeyKind.eq),
        ],
      ];

  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    if (e is! KeyDownEvent && e is! KeyRepeatEvent) return KeyEventResult.ignored;
    final k = e.logicalKey;
    if (k == LogicalKeyboardKey.backspace) {
      c.backspace();
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.delete || k == LogicalKeyboardKey.escape) {
      c.clear();
      return KeyEventResult.handled;
    }
    final ch = e.character;
    if (ch == null || ch.isEmpty) return KeyEventResult.ignored;
    if (ch == '=') {
      c.equals();
      return KeyEventResult.handled;
    }
    if ('0123456789.+-*/()^%!'.contains(ch)) {
      var t = ch;
      if (ch == '*') t = '×';
      if (ch == '/') t = '÷';
      if (ch == '-') t = '−';
      c.press(t);
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    return Focus(
      canRequestFocus: false,
      skipTraversal: true,
      onKeyEvent: _onKey,
      child: ListenableBuilder(
        listenable: c,
        builder: (context, _) => LayoutBuilder(
          builder: (context, box) {
            final wide = isTv || box.maxWidth > box.maxHeight * 1.1;
            if (wide) {
              return Column(
                children: <Widget>[
                  Expanded(flex: 3, child: SciDisplay(c: c)),
                  Expanded(
                    flex: 7,
                    child: Row(
                      children: <Widget>[
                        Expanded(flex: 5, child: keyGrid(_sciKeys())),
                        const SizedBox(width: 10),
                        Expanded(flex: 4, child: keyGrid(_basicKeys())),
                      ],
                    ),
                  ),
                ],
              );
            }
            return Column(
              children: <Widget>[
                Expanded(
                  flex: 3,
                  child: SciDisplay(
                    c: c,
                    onToggleSci: () => setState(() => _showSci = !_showSci),
                  ),
                ),
                if (_showSci) Expanded(flex: 5, child: keyGrid(_sciKeys())),
                Expanded(flex: _showSci ? 5 : 6, child: keyGrid(_basicKeys())),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ----------------------------------------------------------- programmer tab
class ProgPanel extends StatelessWidget {
  const ProgPanel({super.key, required this.c});
  final ProgController c;

  Widget _baseRow(String label, int base) {
    final sel = c.base == base;
    return InkWell(
      onTap: () => c.setBase(base),
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Row(
          children: <Widget>[
            SizedBox(
              width: 48,
              child: Text(label,
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: isTv ? 18 : 15,
                      color: sel ? Pal.eq : Pal.dim)),
            ),
            Expanded(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  ProgController.text(c.cur, base, grouped: true),
                  style: TextStyle(
                      fontSize: isTv ? 20 : 16,
                      color: sel ? Pal.text : Pal.dim),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _display() => Container(
        margin: const EdgeInsets.fromLTRB(4, 4, 4, 6),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0x33000000),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                c.error ?? c.pending,
                textAlign: TextAlign.right,
                style: TextStyle(
                    fontSize: isTv ? 20 : 16,
                    color: c.error != null ? Pal.danger : Pal.dim),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerRight,
                  child: Text(c.mainText,
                      maxLines: 1,
                      style: TextStyle(
                          fontSize: isTv ? 44 : 38,
                          fontWeight: FontWeight.w300,
                          color: Pal.text)),
                ),
              ),
            ),
            _baseRow('HEX', 16),
            _baseRow('DEC', 10),
            _baseRow('OCT', 8),
            _baseRow('BIN', 2),
          ],
        ),
      );

  KeyDef _d(String l, int v, {bool autofocus = false}) =>
      KeyDef(l, () => c.digit(v), enabled: v < c.base, autofocus: autofocus);
  KeyDef _o(String l, {KeyKind kind = KeyKind.op}) =>
      KeyDef(l, () => c.setOp(l), kind: kind);

  List<List<KeyDef?>> _keys() => <List<KeyDef?>>[
        <KeyDef?>[
          _d('A', 10),
          _d('B', 11),
          _d('C', 12),
          KeyDef('AC', c.clear, kind: KeyKind.danger),
          KeyDef('⌫', c.backspace, kind: KeyKind.fn),
        ],
        <KeyDef?>[
          _d('D', 13),
          _d('E', 14),
          _d('F', 15),
          KeyDef('NOT', c.not, kind: KeyKind.fn),
          _o('MOD', kind: KeyKind.fn),
        ],
        <KeyDef?>[_d('7', 7), _d('8', 8), _d('9', 9), _o('AND', kind: KeyKind.fn), _o('÷')],
        <KeyDef?>[_d('4', 4), _d('5', 5), _d('6', 6), _o('OR', kind: KeyKind.fn), _o('×')],
        <KeyDef?>[_d('1', 1), _d('2', 2), _d('3', 3), _o('XOR', kind: KeyKind.fn), _o('−')],
        <KeyDef?>[
          _o('<<', kind: KeyKind.fn),
          _d('0', 0, autofocus: isTv),
          _o('>>', kind: KeyKind.fn),
          KeyDef('=', c.equals, kind: KeyKind.eq),
          _o('+'),
        ],
      ];

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => LayoutBuilder(
        builder: (context, box) {
          final wide = isTv || box.maxWidth > box.maxHeight * 1.1;
          if (wide) {
            return Row(
              children: <Widget>[
                Expanded(flex: 4, child: _display()),
                const SizedBox(width: 8),
                Expanded(flex: 6, child: keyGrid(_keys())),
              ],
            );
          }
          return Column(
            children: <Widget>[
              Expanded(flex: 4, child: _display()),
              Expanded(flex: 7, child: keyGrid(_keys())),
            ],
          );
        },
      ),
    );
  }
}

// ------------------------------------------------------------ converter tab
class ConvPanel extends StatelessWidget {
  const ConvPanel({super.key, required this.c});
  final ConvController c;

  Future<void> _pick(BuildContext context, bool isFrom) async {
    final units = c.category.units;
    final sel = isFrom ? c.from : c.to;
    final picked = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(c.category.name),
        content: SizedBox(
          width: 340,
          child: ListView(
            shrinkWrap: true,
            children: <Widget>[
              for (var i = 0; i < units.length; i++)
                ListTile(
                  autofocus: i == sel,
                  selected: i == sel,
                  title: Text(units[i].name),
                  trailing: Text(units[i].sym),
                  onTap: () => Navigator.pop(ctx, i),
                ),
            ],
          ),
        ),
      ),
    );
    if (picked == null) return;
    if (isFrom) {
      c.setFrom(picked);
    } else {
      c.setTo(picked);
    }
  }

  Widget _card(BuildContext context, String label, Unit u, String value, bool isFrom) {
    return Container(
      margin: const EdgeInsets.fromLTRB(4, 4, 4, 4),
      decoration: BoxDecoration(
        color: const Color(0x33000000),
        borderRadius: BorderRadius.circular(18),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _pick(context, isFrom),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('$label  ▾',
                        style: TextStyle(color: Pal.dim, fontSize: isTv ? 16 : 13)),
                    const SizedBox(height: 2),
                    Text(u.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: Pal.eq,
                            fontWeight: FontWeight.w600,
                            fontSize: isTv ? 20 : 16)),
                  ],
                ),
              ),
              Expanded(
                flex: 2,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerRight,
                  child: Text('$value ${u.sym}',
                      maxLines: 1,
                      style: TextStyle(
                          fontSize: isTv ? 40 : 32,
                          fontWeight: FontWeight.w300,
                          color: Pal.text)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _cats() => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Row(
          children: <Widget>[
            for (var i = 0; i < categories.length; i++)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(categories[i].name),
                  selected: c.cat == i,
                  onSelected: (_) => c.setCat(i),
                ),
              ),
          ],
        ),
      );

  List<List<KeyDef?>> _keys() {
    KeyDef n(String l, {bool autofocus = false}) =>
        KeyDef(l, () => c.key(l), autofocus: autofocus);
    return <List<KeyDef?>>[
      <KeyDef?>[n('7'), n('8'), n('9'), KeyDef('⌫', c.backspace, kind: KeyKind.fn)],
      <KeyDef?>[n('4'), n('5', autofocus: isTv), n('6'), KeyDef('AC', c.clear, kind: KeyKind.danger)],
      <KeyDef?>[n('1'), n('2'), n('3'), n('00')],
      <KeyDef?>[
        KeyDef('±', c.negate, kind: KeyKind.fn),
        n('0'),
        n('.'),
        KeyDef('⇄', c.swap, kind: KeyKind.op),
      ],
    ];
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final cards = Column(
          children: <Widget>[
            Expanded(child: _card(context, 'FROM', c.fromUnit, c.input, true)),
            Expanded(child: _card(context, 'TO', c.toUnit, c.resultText, false)),
          ],
        );
        return LayoutBuilder(
          builder: (context, box) {
            final wide = isTv || box.maxWidth > box.maxHeight * 1.1;
            if (wide) {
              return Row(
                children: <Widget>[
                  Expanded(
                    flex: 5,
                    child: Column(
                      children: <Widget>[
                        SizedBox(height: isTv ? 52 : 46, child: _cats()),
                        Expanded(child: cards),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(flex: 4, child: keyGrid(_keys())),
                ],
              );
            }
            return Column(
              children: <Widget>[
                SizedBox(height: 46, child: _cats()),
                Expanded(flex: 4, child: cards),
                Expanded(flex: 5, child: keyGrid(_keys())),
              ],
            );
          },
        );
      },
    );
  }
}

// -------------------------------------------------------------- history tab
class HistoryPanel extends StatelessWidget {
  const HistoryPanel({super.key, required this.c, required this.onPick});
  final SciController c;
  final void Function(HistoryItem) onPick;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        if (c.history.isEmpty) {
          return const Center(
            child: Text('No calculations yet',
                style: TextStyle(color: Pal.dim, fontSize: 18)),
          );
        }
        return Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
              child: Row(
                children: <Widget>[
                  const Text('History',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Pal.text)),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: c.clearHistory,
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Clear'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: c.history.length,
                itemBuilder: (context, i) {
                  final h = c.history[i];
                  return ListTile(
                    autofocus: isTv && i == 0,
                    title: Text(h.expr,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.right,
                        style: const TextStyle(color: Pal.dim)),
                    subtitle: Text(h.result,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.right,
                        style: TextStyle(
                            color: Pal.text, fontSize: isTv ? 30 : 26)),
                    onTap: () => onPick(h),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
