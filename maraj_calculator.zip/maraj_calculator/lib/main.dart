import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core.dart';
import 'mobile.dart';
import 'tv.dart';
import 'glass.dart';
import 'ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await detectTarget();
  if (isTv) {
    await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }
  runApp(const CalcApp());
}

class CalcApp extends StatelessWidget {
  const CalcApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Maraj Calculator',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
              seedColor: Pal.eq, brightness: Brightness.dark),
          scaffoldBackgroundColor: Colors.transparent,
        ),
        builder: (context, child) => GlassBackdrop(child: child!),
        home: isTv ? const TvHome() : const MobileHome(),
      );
}
